const CACHE='mansuri-kirana-v1';
const ASSETS=['./','./mansuri_kirana_business_app.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET') return;
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(r=>{const copy=r.clone(); caches.open(CACHE).then(c=>c.put(event.request,copy)); return r;}).catch(()=>caches.match('./mansuri_kirana_business_app.html'))));
});
