MANSURI KIRANA PWA
Owner: AALAM MANSURI
Shop: MANSURI KIRANA
Phone: 9754083323

Main app: mansuri_kirana_business_app.html
PWA manifest: manifest.webmanifest
Service worker: service-worker.js
Icons: icons/icon-192.png, icons/icon-512.png

Upload all files/folders to Netlify. Do not open the HTML with file:// if testing PWA installation; PWA features require HTTPS/localhost.
